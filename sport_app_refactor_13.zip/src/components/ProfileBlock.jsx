import React, { useState, useEffect } from 'react'
import { ButtonDelete, ButtonExit } from '@components/Buttons.jsx'
import ProfileData from '@components/profile/ProfileData.jsx'
import TeamAndLeague from '@components/profile/TeamLeague.jsx'
import AccountSection from '@components/profile/AccountSection.jsx'
import { PasswordChangeModal } from '@components/modals/index.js'
import axios from 'axios'

import { API_BASE_URL } from '@constants/api.js'

const ProfileBlock = ({ user, setUser }) => {
  const [editMode, setEditMode] = useState(false)
  const [editModeProfile, setEditModeProfile] = useState(false)
  const [editModeProgress, setEditModeProgress] = useState(false)
  const [editModeAccount, setEditModeAccount] = useState(false)
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false)
  const [weightGoal, setWeightGoal] = useState('lose')
  const [currentWeight, setCurrentWeight] = useState('')
  const [progressData, setProgressData] = useState(60)
  const [activities, setActivities] = useState([])

  const [tempUser, setTempUser] = useState(user)
  const handleProgress = () => {
    const token = localStorage.getItem('token')
    axios
      .get(`${API_BASE_URL}/user/progress`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.status === 200) {
          setProgressData(response.data.progress)
        } else {
          console.error('Error loading progress:', response.data.message)
        }
      })
      .catch((error) => {
        console.error('Error loading progress:', error)
      })
  }

  useEffect(() => {
    setTempUser(user)
  }, [user])

  useEffect(() => {
    const token = localStorage.getItem('token')
    axios
      .get(`${API_BASE_URL}/user/activities/all`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.status === 200) {
          setActivities(response.data.activities)
        } else {
          console.error('Error loading activities:', response.data.message)
        }
      })
      .catch((error) => {
        console.error('Error loading activities:', error)
      })

    axios
      .get(`${API_BASE_URL}/user/progress`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.status === 200) {
          setProgressData(response.data.progress)
        } else {
          console.error('Error loading progress:', response.data.message)
        }
      })
      .catch((error) => {
        console.error('Error loading progress:', error)
      })
  }, [])

  const handleEditClickProfile = () => {
    setEditModeProfile(true)
  }

  const handleEditClickProgress = () => {
    setEditModeProgress(true)
  }

  const handleEditClickAccount = () => {
    setEditModeAccount(true)
  }

  const handleCancelClickProfile = () => {
    setEditModeProfile(false)
    setTempUser(user)
  }

  const handleCancelClickProgress = () => {
    setEditModeProgress(false)
  }

  const handleCancelClickAccount = () => {
    setEditModeAccount(false)
    setTempUser(user)
  }
  const handleUpdateUser = (updatedUser) => {
    setTempUser(updatedUser)
    if (setUser) {
      setUser(updatedUser)
    }
  }

  const handlePasswordChange = () => {
    setIsPasswordModalOpen(true)
  }

  const handlePasswordModalClose = () => {
    setIsPasswordModalOpen(false)
  }

  const handleSave = () => {
    if (!tempUser) {
      console.error('Данные пользователя отсутствуют')
      return
    }
    const token = localStorage.getItem('token')
    axios
      .post(`${API_BASE_URL}/edit_person_data`, tempUser, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.status === 200) {
          setTempUser((prevUser) => ({
            ...prevUser,
            ...tempUser,
          }))
          setEditModeProfile(false)
          handleProgress()
        } else {
          console.error('Ошибка при отправке данных на сервер:', response.data.error)
        }
      })
      .catch((error) => {
        console.error('Ошибка при отправке данных на сервер:', error)
      })
  }

  const handleSaveGoal = () => {
    if (!tempUser) {
      console.error('Данные пользователя отсутствуют')
      return
    }
    const token = localStorage.getItem('token')
    axios
      .post(`${API_BASE_URL}/user/set_goal`, tempUser, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.status === 200) {
          setTempUser((prevUser) => ({
            ...prevUser,
            ...tempUser,
          }))
          setEditModeProgress(false)
          handleProgress()
        } else {
          console.error('Ошибка при отправке данных на сервер:', response.data.error)
        }
      })
      .catch((error) => {
        console.error('Ошибка при отправке данных на сервер:', error)
      })
  }

  const handleSaveInfo = () => {
    if (!tempUser) {
      console.error('Данные пользователя отсутствуют')
      return
    }
    const token = localStorage.getItem('token')
    axios
      .post(`${API_BASE_URL}/edit_fio_data`, tempUser, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.status === 200) {
          setTempUser((prevUser) => ({
            ...prevUser,
            ...tempUser,
          }))
          setEditModeProgress(false)
        } else {
          console.error('Ошибка при отправке данных на сервер:', response.data.error)
        }
      })
      .catch((error) => {
        console.error('Ошибка при отправке данных на сервер:', error)
      })
  }

  const handleSaveClickProfile = () => {
    setEditModeProfile(false)
    setTempUser(user)
    handleSave()
  }

  const handleSaveClickProgress = () => {
    setEditModeProgress(false)
    setTempUser(user)
    handleSaveGoal()
  }

  const handleSaveClickAccount = () => {
    setEditModeAccount(false)
    setTempUser(user)
    handleSaveInfo()
  }
  const handleExit = () => {
    const token = localStorage.getItem('token')
    if (!token) {
      console.error('Токен не найден. Пользователь уже не авторизован.')
      window.location.href = '/'
      return
    }
    axios
      .post(
        `${API_BASE_URL}/logout`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` },
        },
      )
      .then((response) => {
        if (response.data.status === 200) {
          window.location.href = '/'
          localStorage.removeItem('token')
        } else {
          console.error('Ошибка при выходе из аккаунта:', response.data.error)
        }
      })
      .catch((error) => {
        console.error('Ошибка при выходе из аккаунта:', error)
        window.location.href = '/'
        localStorage.removeItem('token')
      })
  }

  const handleDelete = () => {
    axios
      .delete(`${API_BASE_URL}/delete_account`)
      .then((response) => {
        if (response.data.status === 200) {
          window.location.href = `main`
        } else {
          console.error('Ошибка при удалении аккаунта:', response.data.error)
        }
      })
      .catch((error) => {
        console.error('Ошибка при удалении аккаунта:', error)
      })
  }

  const handleInputChange = (event, field) => {
    setTempUser((prevState) => ({
      ...prevState,
      [field]: event.target.value,
    }))
  }

  const getColorCode = (bmi) => {
    if (bmi <= 16) return '#6699CC'
    else if (bmi > 16 && bmi <= 18.5) return '#339966'
    else if (bmi > 18.5 && bmi <= 25) return '#33CC66'
    else if (bmi > 25 && bmi <= 30) return '#00CC00'
    else if (bmi > 30 && bmi <= 35) return '#FF6600'
    else if (bmi > 35 && bmi <= 40) return '#FF3300'
    else return '#FF0000'
  }

  if (!tempUser) {
    return <div>Loading...</div>
  }

  const getLeagueColor = (league) => {
    switch (league) {
      case 'bronze':
        return '#ed96ad'
      case 'silver':
        return '#91aee1'
      case 'gold':
        return '#f5dc8b'
      default:
        return '#FFFFFF'
    }
  }
  const leagueColor = getLeagueColor(tempUser.league)

  const handleKeyPress = (event) => {
    if (!/[0-9]/.test(event.key)) {
      event.preventDefault()
    }
  }

  return (
    <div className="profile-block">
      <img
        src={
          tempUser.avatar
            ? tempUser.avatar
            : 'https://www.shutterstock.com/image-vector/avatar-photo-default-user-icon-600nw-2345549599.jpg'
        }
        alt={`${tempUser.firstName} ${tempUser.lastName}`}
        className="profile-block-avatar"
      />
      <span className="profile-block-name">{`${tempUser.lastName} ${tempUser.firstName}`}</span>
      {tempUser.status && (
        <div className="profile-block-status" title={tempUser.status}>
          {tempUser.status}
        </div>
      )}

      <div className="profile-block-content">
        <TeamAndLeague tempUser={tempUser} leagueColor={leagueColor} />
        <ProfileData
          tempUser={tempUser}
          editModeProfile={editModeProfile}
          handleInputChange={handleInputChange}
          handleCancelClickProfile={handleCancelClickProfile}
          handleSaveClickProfile={handleSaveClickProfile}
          handleEditClickProfile={handleEditClickProfile}
        />
        <div className="profile-block-content-data">
          <div className="profile-block-content-data-title">
            <p className="profile-block-content-data-title-name">Мой прогресс</p>
          </div>
          <div className="profile-block-content-data-line" />
          <div className="profile-block-content-data-item">
            <div className="profile-block__activity-list">
              {activities.map((activity, index) => (
                <div
                  key={index}
                  className={`profile-block__activity-list-item ${activity.tag}-metric position-relative`}
                >
                  <div
                    key={activity.type}
                    id={activity.tag}
                    className={`activity-tags ${activity.tag}-S width-100`}
                  >
                    {activity.type.toUpperCase()}
                  </div>
                  <div className={`profile-block__activity-list-item-time ${activity.tag}`}>
                    {activity.time} часов
                  </div>
                </div>
              ))}
            </div>
            {/* <div className="profile-block-content-data-line"/> */}
          </div>
        </div>
        <div className="profile-block-content-data">
          <div className="profile-block-content-data-title">
            <p className="profile-block-content-data-title-name">Желаемый вес</p>

            {editModeProgress ? (
              <>
                <button
                  onClick={handleEditClickProgress}
                  className="profile-block-content-data-title-pen"
                >
                  <svg
                    width="22"
                    height="23"
                    viewBox="0 0 22 23"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M15.3845 2.53553C16.5561 1.36396 18.4556 1.36396 19.6272 2.53553C20.7988 3.70711 20.7988 5.6066 19.6272 6.77817L13.9703 12.435L8.44099 17.9644C8.00189 18.4035 7.46659 18.7343 6.87747 18.9307L1.40933 20.7534L3.23522 15.2757C3.4295 14.6929 3.75682 14.1633 4.19124 13.7288L15.3845 2.53553Z"
                      fill="url(#paint0_linear_580_1299)"
                      stroke="url(#paint1_linear_580_1299)"
                      strokeWidth="2"
                    />
                    <defs>
                      <linearGradient
                        id="paint0_linear_580_1299"
                        x1="-3.00024"
                        y1="19.5061"
                        x2="3.7211"
                        y2="25.7123"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stopColor="#9D9DE6" />
                        <stop offset="0.427083" stopColor="#567FE3" />
                        <stop offset="0.885417" stopColor="#9664C8" />
                      </linearGradient>
                      <linearGradient
                        id="paint1_linear_580_1299"
                        x1="-3.00024"
                        y1="19.5061"
                        x2="3.7211"
                        y2="25.7123"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stopColor="#9D9DE6" />
                        <stop offset="0.427083" stopColor="#567FE3" />
                        <stop offset="0.885417" stopColor="#9664C8" />
                      </linearGradient>
                    </defs>
                  </svg>
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={handleEditClickProgress}
                  className="profile-block-content-data-title-pen"
                >
                  <svg
                    width="22"
                    height="23"
                    viewBox="0 0 22 23"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M15.3845 2.53553C16.5561 1.36396 18.4556 1.36396 19.6272 2.53553C20.7988 3.70711 20.7988 5.6066 19.6272 6.77817L13.9703 12.435L8.44099 17.9644C8.00189 18.4035 7.46659 18.7343 6.87747 18.9307L1.40933 20.7534L3.23522 15.2757C3.4295 14.6929 3.75682 14.1633 4.19124 13.7288L15.3845 2.53553Z"
                      stroke="#E0E0E0"
                      strokeWidth="2"
                    />
                  </svg>
                </button>
              </>
            )}
          </div>
          <div className="profile-block-content-data-items">
            <div className="profile-block-content-data-item-oval">
              {editModeProgress ? (
                <input
                  className="profile-block-content-data-item-oval-input"
                  type="number"
                  value={tempUser.target_weight}
                  onKeyPress={handleKeyPress}
                  min="1"
                  onChange={(event) => handleInputChange(event, 'target_weight')}
                />
              ) : (
                <p className="profile-block-content-data-item-oval-text">
                  {tempUser.target_weight}
                </p>
              )}
              <label className="profile-label">кг</label>
            </div>
          </div>
          <p className="profile-block-content-data-title-name-small">
            Прогресс от начального веса к желаемому
          </p>
          <div className="progress-bar progress-bar-margin-top">
            <div className="progress" style={{ width: `${progressData}%` }}></div>
          </div>

          {editModeProgress && (
            <div className="profile-block-content-data-btn">
              <button
                onClick={handleCancelClickProgress}
                className="profile-block-content-data-btn-cancel"
              >
                Отменить
              </button>
              <button
                onClick={handleSaveClickProgress}
                className="profile-block-content-data-btn-save"
              >
                Сохранить
              </button>
            </div>
          )}
        </div>
        <AccountSection
          tempUser={tempUser}
          editModeAccount={editModeAccount}
          handleInputChange={handleInputChange}
          handleCancelClickAccount={handleCancelClickAccount}
          handleSaveClickAccount={handleSaveClickAccount}
          handleEditClickAccount={handleEditClickAccount}
          handleUpdateUser={handleUpdateUser}
          handlePasswordChange={handlePasswordChange}
        />
      </div>
      <div className="profile-block-btn">
        <ButtonExit
          text="Выйти из аккаунта"
          textContent={'Выйти из аккаунта'}
          onClick={handleExit}
        />
        {/*
        <ButtonDelete
          text="Удалить аккаунт"
          textContent={'Удалить аккаунт'}
          onClick={handleDelete}
        />
        */}
      </div>

      {isPasswordModalOpen && (
        <PasswordChangeModal isOpen={isPasswordModalOpen} onClose={handlePasswordModalClose} />
      )}
    </div>
  )
}

export default ProfileBlock
