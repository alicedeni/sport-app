import React from 'react'
import { ButtonProfile } from '@components/Buttons.jsx'

const Notification = ({ isOpen, userName, onClose }) => {
  if (!isOpen) {
    return null
  }

  return (
    <div className="header-notification">
      <h1 className="header-notification-title">Привет, {userName}!</h1>
      <p className="header-notification-text">
        Рады видеть тебя в нашем спортивном челлендже. Наша глобальная цель — Прошагать 10 562 км .
        <br></br>Основное соревнование начнется совсем скоро, а пока что ты можешь заполнить данные
        о себе и свои персональные цели в личном профиле.
      </p>
      <ButtonProfile
        className="welcome-block__btn"
        text="Личный профиль"
        textContent={'Личный профиль'}
      ></ButtonProfile>
      <button className="header-notification-close" onClick={onClose}>
        <svg
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            x="3"
            y="6.53552"
            width="5"
            height="42"
            rx="2.5"
            transform="rotate(-45 3 6.53552)"
            fill="#BDBDBD"
          />
          <rect
            width="5"
            height="42"
            rx="2.5"
            transform="matrix(0.707107 0.707107 0.707107 -0.707107 3 33)"
            fill="#BDBDBD"
          />
        </svg>
      </button>
    </div>
  )
}

export default Notification
