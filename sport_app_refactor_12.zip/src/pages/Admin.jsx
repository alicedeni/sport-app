import React from 'react'
import AdminPanel from './AdminPanel'

const Admin = () => {
  return <AdminPanel />
}

export default Admin
