import api from './api'
import { API_ENDPOINTS } from '../../constants/api'

export const userService = {
  getMainInfo: () => api.get('/profile'),
  getMainData: () => api.get('/main'),
  hideWelcome: () => api.post(API_ENDPOINTS.HIDE_WELCOME),
}
