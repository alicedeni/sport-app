import React, { useState, useEffect } from 'react'
import { ButtonEnter } from '../Buttons'

const MobileGoalBlock = () => {
  const [currentPage, setCurrentPage] = useState(0)
  const [isImageLoaded, setIsImageLoaded] = useState(false)

  const handlePrevPage = () => {
    setCurrentPage(currentPage === 0 ? 4 : currentPage - 1)
  }

  const handleNextPage = () => {
    setCurrentPage((currentPage + 1) % 5)
  }

  const handleGoToMain = () => {
    window.location.href = '/main'
  }

  const pages = [
    {
      title: 'SportUp: от Калининграда до Владивостока',
      text: 'В рамках пилота приложения мы запустили спортивный челлендж, целью которого является преодолеть расстояние в 10 562 км – от Калининграда до Владивостока. Важно, не только двигаться к цели, но и активно взаимодействовать с командой, поддерживая дух соперничества!',
      imageUrl: 'https://storage.yandexcloud.net/team2go/users/base/cat1.svg',
      imagePosition: { top: '100px', right: '0' },
    },
    {
      title: 'БАЛЛЫ',
      text: 'Баллы - это внутренняя валюта челленджа. Вы можете выбирать и заносить самостоятельно любые виды активности: бег, пешие прогулки, велопоездки и даже плавание, которые будут преобразовываться в километры, а затем в баллы и добавляться к общему результату команды.',
      imageUrl: 'https://storage.yandexcloud.net/team2go/users/base/cat2.svg',
      imagePosition: { top: '140px', right: '30px' },
    },
    {
      title: 'ПРИЗЫ',
      listItems: [
        {
          text: 'Ведите активный образ жизни и получайте за это заслуженные награды! ТОП-3 среди командного рейтинга и индивидуального получат крутой мерч от цифрового бренда!',
        },
        {
          text: 'Следите за успехами своих коллег, делитесь фотоотчетами о своих достижениях и активностях. Каждый ваш шаг приближает вашу команду к лидирующей позиции. Помните, что вместе вы сможете больше! ',
        },
        {
          text: 'P.S. кто будет активно делиться фото и видео со своих тренировок, мы выделим отдельно и наградим!',
        },
      ],
    },
    {
      title: 'ЗАДАЧИ',
      text: 'Задачи на период челленджа «от Калининграда до Владивостока»:',
      imageUrl: '',
      imagePosition: {},
      listItems: [
        {
          text: 'Заполнить личный профиль',
          svgIcon:
            '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
            '<path d="M25.5 18.4315C25.5 15.9184 25.0965 12.0623 22.3843 10.1077C22.2387 10.0028 22.0486 10.1685 22.1055 10.3393C22.4411 11.3462 22.5 13.4323 21.5 13.4323C20.5 13.4323 20.89 12.4104 20.6806 11.2415L20.6806 11.2415C20.5567 10.5495 20.4079 9.71893 20.0714 8.87259C19.2108 6.70761 17.5314 3.71888 12.6971 3.43258C12.5065 3.4213 12.3798 3.76444 12.4962 3.91681C13.9003 5.75632 14.5101 11.4323 12.5 11.4323C11.2779 11.4323 11.4041 9.30309 12.1256 7.60633C12.1963 7.43993 12.0142 7.27383 11.8633 7.37234C6.92323 10.5975 6.5 15.8576 6.5 18.4315C6.5 18.4315 6.53809 28.5676 16.019 28.5676C25.5 28.5676 25.5 18.4315 25.5 18.4315Z" fill="url(#paint0_linear_1659_2145)"/>\n' +
            '<path d="M17.4997 25H15.3717V17.496L13.0617 18.588L12.3617 17.118L16.2817 15.186H17.4997V25Z" fill="white"/>\n' +
            '<defs>\n' +
            '<linearGradient id="paint0_linear_1659_2145" x1="6.5" y1="28.5676" x2="27.9884" y2="26.2212" gradientUnits="userSpaceOnUse">\n' +
            '<stop stop-color="#9D9DE6"/>\n' +
            '<stop offset="0.427083" stop-color="#567FE3"/>\n' +
            '<stop offset="0.885417" stop-color="#9664C8"/>\n' +
            '</linearGradient>\n' +
            '</defs>\n' +
            '</svg>',
        },
        {
          text: 'Вносить информацию по своим активностям',
          svgIcon:
            '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
            '<path d="M25.5 18.4316C25.5 15.9184 25.0965 12.0624 22.3843 10.1077C22.2387 10.0028 22.0486 10.1686 22.1055 10.3394C22.4411 11.3462 22.5 13.4323 21.5 13.4323C20.5 13.4323 20.89 12.4104 20.6806 11.2416L20.6806 11.2416C20.5567 10.5496 20.4079 9.71896 20.0714 8.87262C19.2108 6.70764 17.5314 3.71891 12.6971 3.43261C12.5065 3.42133 12.3798 3.76447 12.4962 3.91684C13.9003 5.75635 14.5101 11.4323 12.5 11.4323C11.2779 11.4323 11.4041 9.30312 12.1256 7.60636C12.1963 7.43996 12.0142 7.27386 11.8633 7.37237C6.92323 10.5976 6.5 15.8576 6.5 18.4316C6.5 18.4316 6.53809 28.5677 16.019 28.5677C25.5 28.5677 25.5 18.4316 25.5 18.4316Z" fill="url(#paint0_linear_1659_2150)"/>\n' +
            '<path d="M13.2633 18.504L11.8353 17.538C12.5633 15.886 14.2293 15.074 16.0073 15.074C18.3873 15.074 19.7173 16.334 19.7173 18.182C19.7173 20.464 17.7713 21.794 15.7273 22.9L15.1673 23.208C15.1673 23.236 15.1673 23.25 15.1673 23.278C15.7273 23.222 16.0493 23.208 16.5113 23.208H19.8293V25H11.9753V23.544L13.7813 22.312C15.7553 20.954 17.5753 19.806 17.5753 18.42C17.5753 17.594 17.1273 16.936 15.8253 16.936C14.6633 16.936 13.6833 17.776 13.2633 18.504Z" fill="white"/>\n' +
            '<defs>\n' +
            '<linearGradient id="paint0_linear_1659_2150" x1="6.5" y1="28.5677" x2="27.9884" y2="26.2212" gradientUnits="userSpaceOnUse">\n' +
            '<stop stop-color="#9D9DE6"/>\n' +
            '<stop offset="0.427083" stop-color="#567FE3"/>\n' +
            '<stop offset="0.885417" stop-color="#9664C8"/>\n' +
            '</linearGradient>\n' +
            '</defs>\n' +
            '</svg>',
        },
        {
          text: 'Отслеживать рейтинги',
          svgIcon:
            '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
            '<path d="M25.5 18.4316C25.5 15.9184 25.0965 12.0624 22.3843 10.1077C22.2387 10.0028 22.0486 10.1686 22.1055 10.3394C22.4411 11.3462 22.5 13.4323 21.5 13.4323C20.5 13.4323 20.89 12.4104 20.6806 11.2416L20.6806 11.2416C20.5567 10.5496 20.4079 9.71896 20.0714 8.87262C19.2108 6.70764 17.5314 3.71891 12.6971 3.43261C12.5065 3.42133 12.3798 3.76447 12.4962 3.91684C13.9003 5.75635 14.5101 11.4323 12.5 11.4323C11.2779 11.4323 11.4041 9.30312 12.1256 7.60636C12.1963 7.43996 12.0142 7.27386 11.8633 7.37237C6.92323 10.5976 6.5 15.8576 6.5 18.4316C6.5 18.4316 6.53809 28.5677 16.019 28.5677C25.5 28.5677 25.5 18.4316 25.5 18.4316Z" fill="url(#paint0_linear_1659_2155)"/>\n' +
            '<path d="M13.0742 17.888L11.8282 16.614C12.6262 15.774 13.9142 15.046 15.9302 15.046C17.9462 15.046 19.6262 16.012 19.6262 17.65C19.6262 18.56 19.1362 19.386 18.0162 19.666C18.0162 19.708 18.0022 19.75 17.9882 19.778C19.2902 20.03 19.9482 20.884 19.9482 21.99C19.9482 23.852 18.2542 25.112 15.9442 25.112C14.0682 25.112 12.7522 24.678 11.7722 23.544L12.9902 22.2C13.7882 22.914 14.7122 23.25 15.9162 23.25C16.6582 23.25 17.2462 22.998 17.5682 22.606C17.7362 22.41 17.8062 22.186 17.8062 21.948C17.7922 21.234 17.1062 20.87 15.8602 20.87H14.3342V19.218H15.5802C16.4902 19.218 17.0502 18.91 17.3022 18.532C17.4282 18.35 17.4982 18.14 17.4842 17.958C17.4842 17.37 16.7702 16.908 15.7342 16.908C14.4882 16.908 13.7882 17.272 13.0742 17.888Z" fill="white"/>\n' +
            '<defs>\n' +
            '<linearGradient id="paint0_linear_1659_2155" x1="6.5" y1="28.5677" x2="27.9884" y2="26.2212" gradientUnits="userSpaceOnUse">\n' +
            '<stop stop-color="#9D9DE6"/>\n' +
            '<stop offset="0.427083" stop-color="#567FE3"/>\n' +
            '<stop offset="0.885417" stop-color="#9664C8"/>\n' +
            '</linearGradient>\n' +
            '</defs>\n' +
            '</svg>',
        },
        {
          text: 'Делиться обратной связью',
          svgIcon:
            '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
            '<path d="M25.5 18.4316C25.5 15.9184 25.0965 12.0624 22.3843 10.1077C22.2387 10.0028 22.0486 10.1686 22.1055 10.3394C22.4411 11.3462 22.5 13.4323 21.5 13.4323C20.5 13.4323 20.89 12.4104 20.6806 11.2416L20.6806 11.2416C20.5567 10.5496 20.4079 9.71896 20.0714 8.87262C19.2108 6.70764 17.5314 3.71891 12.6971 3.43261C12.5065 3.42133 12.3798 3.76447 12.4962 3.91684C13.9003 5.75635 14.5101 11.4323 12.5 11.4323C11.2779 11.4323 11.4041 9.30312 12.1256 7.60636C12.1963 7.43996 12.0142 7.27386 11.8633 7.37237C6.92323 10.5976 6.5 15.8576 6.5 18.4316C6.5 18.4316 6.53809 28.5677 16.019 28.5677C25.5 28.5677 25.5 18.4316 25.5 18.4316Z" fill="url(#paint0_linear_1659_2160)"/>\n' +
            '<path d="M16.4145 25V23.264H10.7165V22.06L16.7505 15.186H18.4165V21.612H20.2085V23.264H18.4165V25H16.4145ZM13.1805 21.612H16.4145V17.972L13.1805 21.612Z" fill="white"/>\n' +
            '<defs>\n' +
            '<linearGradient id="paint0_linear_1659_2160" x1="6.5" y1="28.5677" x2="27.9884" y2="26.2212" gradientUnits="userSpaceOnUse">\n' +
            '<stop stop-color="#9D9DE6"/>\n' +
            '<stop offset="0.427083" stop-color="#567FE3"/>\n' +
            '<stop offset="0.885417" stop-color="#9664C8"/>\n' +
            '</linearGradient>\n' +
            '</defs>\n' +
            '</svg>',
        },
        {
          text: 'Следить за прогрессом к глобальной цели',
          svgIcon:
            '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">\n' +
            '<path d="M25.5 18.4316C25.5 15.9184 25.0965 12.0624 22.3843 10.1077C22.2387 10.0028 22.0486 10.1686 22.1055 10.3394C22.4411 11.3462 22.5 13.4323 21.5 13.4323C20.5 13.4323 20.89 12.4104 20.6806 11.2416L20.6806 11.2416C20.5567 10.5496 20.4079 9.71896 20.0714 8.87262C19.2108 6.70764 17.5314 3.71891 12.6971 3.43261C12.5065 3.42133 12.3798 3.76447 12.4962 3.91684C13.9003 5.75635 14.5101 11.4323 12.5 11.4323C11.2779 11.4323 11.4041 9.30312 12.1256 7.60636C12.1963 7.43996 12.0142 7.27386 11.8633 7.37237C6.92323 10.5976 6.5 15.8576 6.5 18.4316C6.5 18.4316 6.53809 28.5677 16.019 28.5677C25.5 28.5677 25.5 18.4316 25.5 18.4316Z" fill="url(#paint0_linear_1659_2165)"/>\n' +
            '<path d="M12.2762 20.114L12.7942 15.2H19.4582V17.202H14.2642L14.0822 18.798C14.4462 18.602 15.3562 18.476 16.2942 18.476C18.6742 18.476 20.0182 19.806 20.0182 21.738C20.0182 23.782 18.1702 25.112 15.7902 25.112C14.1242 25.112 12.5982 24.58 11.9122 23.6L13.1162 22.312C13.8442 23.026 14.6702 23.25 15.7342 23.25C17.1482 23.25 17.8762 22.578 17.8762 21.668C17.8762 20.758 17.2322 20.198 15.7062 20.198C14.6702 20.198 14.0402 20.422 13.4102 20.814L12.2762 20.114Z" fill="white"/>\n' +
            '<defs>\n' +
            '<linearGradient id="paint0_linear_1659_2165" x1="6.5" y1="28.5677" x2="27.9884" y2="26.2212" gradientUnits="userSpaceOnUse">\n' +
            '<stop stop-color="#9D9DE6"/>\n' +
            '<stop offset="0.427083" stop-color="#567FE3"/>\n' +
            '<stop offset="0.885417" stop-color="#9664C8"/>\n' +
            '</linearGradient>\n' +
            '</defs>\n' +
            '</svg>',
        },
      ],
    },
    {
      title: 'СРОКИ',
      text: (
        <>
          Старт мероприятия: <span style={{ color: '#51B8FF' }}>18.06</span>
          <br />
          Подведение итогов: <span style={{ color: '#51B8FF' }}>18.07</span>
        </>
      ),
      imageUrl: 'https://storage.yandexcloud.net/team2go/users/base/cat5.svg',
      buttonText: 'Поехали!',
      imagePosition: { top: '70px', right: '50px' },
    },
  ]

  useEffect(() => {
    setIsImageLoaded(false)
  }, [currentPage])

  return (
    <div className="mobile-goal-block">
      <div className="mobile-goal-block__header">
        <p className="mobile-goal-block__subtitle">СПОРТИВНЫЙ ЧЕЛЛЕНДЖ</p>
        <h1 className="mobile-goal-block__title">{pages[currentPage].title}</h1>
      </div>
      <div className="mobile-goal-block__body">
        <div>
          <p className="mobile-goal-block__text">{pages[currentPage].text}</p>
          {pages[currentPage].listItems && (
            <ul className="mobile-task-list">
              {pages[currentPage].listItems.map((item, index) => (
                <li key={index} className="mobile-task-list__item">
                  <span
                    className="mobile-task-list__item-icon"
                    dangerouslySetInnerHTML={{ __html: item.svgIcon }}
                  />
                  {item.text}
                </li>
              ))}
            </ul>
          )}
        </div>
        {pages[currentPage].imageUrl && (
          <img
            className="mobile-goal__image-mob"
            key={pages[currentPage].imageUrl}
            src={pages[currentPage].imageUrl}
            alt={`cat ${currentPage + 1}`}
            style={{ position: 'absolute', ...pages[currentPage].imagePosition }}
            onLoad={() => setIsImageLoaded(true)}
          />
        )}
        <div>
          {currentPage === 4 && (
            <ButtonEnter
              className="welcome-block__btn"
              text="Поехали!"
              textContent={'Поехали!'}
              onClick={handleGoToMain}
            ></ButtonEnter>
          )}
          <div className="mobile-goal-block__arrow">
            <button
              className="mobile-goal-block__arrow-prev"
              onClick={handlePrevPage}
              style={{ visibility: currentPage === 0 ? 'hidden' : 'visible' }}
            >
              &lt;
            </button>
            <div className="mobile-goal-block__indicators">
              {pages.map((_, index) => (
                <span
                  key={index}
                  className={`indicator ${currentPage === index ? 'active' : ''}`}
                  onClick={() => setCurrentPage(index)}
                ></span>
              ))}
            </div>
            <button
              className="mobile-goal-block__arrow-next"
              onClick={handleNextPage}
              style={{ visibility: currentPage === 4 ? 'hidden' : 'visible' }}
            >
              &gt;
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MobileGoalBlock
