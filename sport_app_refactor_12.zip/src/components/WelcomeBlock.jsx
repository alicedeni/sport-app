import React, { useState } from 'react'
import axios from 'axios'
import { ButtonEnter, ButtonReg } from './Buttons'

import { API_BASE_URL } from '../constants/api.js'

const WelcomeBlock = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const handleLogin = (event) => {
    event.preventDefault()
    if (email.trim() === '' || password.trim() === '') {
      setError('Пожалуйста, введите логин и пароль.')
    } else {
      setError('')
      const token = localStorage.getItem('token')
      axios
        .post(
          `${API_BASE_URL}/login`,
          { email, password },
          {
            headers: { Authorization: `Bearer ${token}` },
          },
        )
        .then((response) => {
          if (response.data.status === 200) {
            localStorage.setItem('token', response.data.token)
            checkHelloStatus()
          } else {
            console.error(error)
            setError('Введен неверный логин или пароль.')
          }
        })
        .catch((error) => {
          console.error('Ошибка Axios:', error)
          if (error.response) {
            console.error('Данные ответа:', error.response.data)
            console.error('Статус ответа:', error.response.status)
          } else if (error.request) {
            console.error('Запрос был сделан, но ответа не получено:', error.request)
          } else {
            console.error('Ошибка при настройке запроса:', error.message)
          }
          setError('Произошла ошибка при входе.')
        })
    }
  }

  const checkHelloStatus = () => {
    const token = localStorage.getItem('token')
    axios
      .get(`${API_BASE_URL}/user/get_hello_status`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        if (response.data.f_hello === false) {
          axios
            .post(
              `${API_BASE_URL}/user/update_f_hello`,
              {},
              {
                headers: { Authorization: `Bearer ${token}` },
              },
            )
            .then(() => {
              window.location.href = '/about'
            })
            .catch((error) => {
              console.error('Error updating f_hello', error)
              setError('Произошла ошибка при обновлении статуса.')
            })
        } else {
          window.location.href = `/main`
        }
      })
      .catch((error) => {
        console.error('Error checking hello status', error)
        setError('Произошла ошибка при проверке статуса.')
      })
  }

  return (
    <div className="welcome-block">
      <h1 className="welcome-block__text">Добро пожаловать!</h1>
      <form onSubmit={handleLogin}>
        <input
          className="welcome-block__input"
          type="text"
          placeholder="Логин"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          className="welcome-block__input"
          type="password"
          placeholder="Пароль"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <div className="welcome-block__error">
          {error && <p className="error error-text">{error}</p>}
        </div>
        <ButtonEnter
          className="welcome-block__btn"
          text="Войти"
          textContent={'Войти'}
        ></ButtonEnter>
      </form>
      <ButtonReg
        className="welcome-block__btn"
        text="Зарегистрироваться"
        textContent={'Зарегистрировать'}
      ></ButtonReg>
    </div>
  )
}

export default WelcomeBlock
