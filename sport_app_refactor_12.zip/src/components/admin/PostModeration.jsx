import React, { useState, useEffect, useMemo } from 'react'
import { adminService } from '@shared/services/adminService'

const PostModeration = () => {
  const [posts, setPosts] = useState([])
  const [pagination, setPagination] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [filters, setFilters] = useState({
    status: '',
    authorId: '',
    activityId: '',
    from: '',
    to: '',
    page: 1,
    limit: 20,
  })

  const loadPosts = async () => {
    setLoading(true)
    setError(null)
    try {
      const params = {
        page: filters.page,
        limit: filters.limit,
        ...(filters.status && { status: filters.status }),
        ...(filters.authorId && { author_id: filters.authorId }),
        ...(filters.activityId && { activity_id: filters.activityId }),
        ...(filters.from && { from: filters.from }),
        ...(filters.to && { to: filters.to }),
        ...(searchTerm && { query: searchTerm }),
      }

      const response = await adminService.getPosts(params)
      if (response.data.status === 200) {
        setPosts(response.data.data.posts || [])
        setPagination(response.data.data.pagination || null)
      } else {
        setError(response.data.error || response.data.message || 'Ошибка загрузки постов')
      }
    } catch (err) {
      setError(err.response?.data?.error || err.message || 'Ошибка при загрузке постов')
      console.error('Ошибка загрузки постов:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadPosts()
  }, [filters.page, filters.status, filters.authorId, filters.activityId, filters.from, filters.to])

  useEffect(() => {
    const timer = setTimeout(() => {
      if (filters.page === 1) {
        loadPosts()
      } else {
        setFilters({ ...filters, page: 1 })
      }
    }, 500)

    return () => clearTimeout(timer)
  }, [searchTerm])

  const handleUpdateStatus = async (postId, newStatus) => {
    try {
      const response = await adminService.updatePostStatus(postId, newStatus)
      if (response.data.status === 200) {
        await loadPosts()
      } else {
        alert(response.data.error || response.data.message || 'Ошибка обновления статуса')
      }
    } catch (err) {
      alert(err.response?.data?.error || err.message || 'Ошибка при обновлении статуса')
    }
  }

  const handleDeletePost = async (postId) => {
    if (!window.confirm('Вы уверены, что хотите удалить этот пост?')) {
      return
    }

    try {
      const response = await adminService.deletePost(postId)
      if (response.data.status === 200) {
        await loadPosts()
      } else {
        alert(response.data.error || response.data.message || 'Ошибка удаления поста')
      }
    } catch (err) {
      alert(err.response?.data?.error || err.message || 'Ошибка при удалении поста')
    }
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      visible: { text: 'Видимый', class: 'admin-post-status--visible' },
      hidden: { text: 'Скрыт', class: 'admin-post-status--hidden' },
    }
    const config = statusConfig[status] || statusConfig.visible
    return <span className={`admin-post-status ${config.class}`}>{config.text}</span>
  }

  const filteredPosts = useMemo(() => {
    if (!searchTerm) return posts
    const needle = searchTerm.trim().toLowerCase()
    return posts.filter((post) => {
      const fullName = `${post.authorName || ''} ${post.authorSurname || ''}`.trim().toLowerCase()
      return fullName.includes(needle)
    })
  }, [posts, searchTerm])

  return (
    <div className="admin-post-moderation">
      <div className="admin-post-moderation__header">
        <h1 className="admin-post-moderation__title">Модерация постов</h1>
        <div className="admin-post-moderation__filters">
          <div className="admin-search">
            <input
              type="text"
              placeholder="Поиск по имени автора..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="admin-search__input"
            />
          </div>
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
            className="admin-select"
          >
            <option value="">Все статусы</option>
            <option value="visible">Видимые</option>
            <option value="hidden">Скрытые</option>
          </select>
          <input
            type="date"
            placeholder="С"
            value={filters.from}
            onChange={(e) => setFilters({ ...filters, from: e.target.value, page: 1 })}
            className="admin-input"
          />
          <input
            type="date"
            placeholder="До"
            value={filters.to}
            onChange={(e) => setFilters({ ...filters, to: e.target.value, page: 1 })}
            className="admin-input"
          />
        </div>
      </div>

      {error && (
        <div className="admin-error-message" style={{ color: 'red', padding: '10px' }}>
          {error}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '20px' }}>Загрузка...</div>
      ) : (
        <>
          <div className="admin-post-list">
            {filteredPosts.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '20px' }}>Посты не найдены</div>
            ) : (
              filteredPosts.map((post) => (
                <div key={post.id} className="admin-post-item">
                  <div className="admin-post-item__header">
                    <div className="admin-post-item__author">
                      {post.authorName} {post.authorSurname}
                    </div>
                    <div className="admin-post-item__date">
                      {new Date(post.timeOfPublication || post.activityDate).toLocaleDateString()}
                    </div>
                    {getStatusBadge(post.status)}
                  </div>
                  <div className="admin-post-item__body">
                    <div className="admin-post-item__activity">
                      {post.activityName} ({post.activityTag})
                    </div>
                    {post.description && (
                      <div className="admin-post-item__description">{post.description}</div>
                    )}
                    <div className="admin-post-item__stats">
                      <span>Дистанция: {post.distance || '-'}</span>
                      <span>Калории: {post.calories || '-'}</span>
                      <span>Баллы: {post.points || 0}</span>
                      <span>Лайки: {post.likeCount || 0}</span>
                      <span>Комментарии: {post.commentCount || 0}</span>
                    </div>
                    {post.image && (
                      <img
                        src={post.image}
                        alt="Post"
                        style={{ maxWidth: '200px', maxHeight: '200px' }}
                      />
                    )}
                  </div>
                  <div className="admin-post-item__actions">
                    <button
                      className="admin-btn admin-btn--small admin-btn--warning"
                      onClick={() =>
                        handleUpdateStatus(
                          post.id,
                          post.status === 'visible' ? 'hidden' : 'visible',
                        )
                      }
                    >
                      {post.status === 'visible' ? 'Скрыть' : 'Показать'}
                    </button>
                    <button
                      className="admin-btn admin-btn--small admin-btn--danger"
                      onClick={() => handleDeletePost(post.id)}
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {pagination && (
            <div className="admin-pagination">
              <button
                className="admin-btn admin-btn--small"
                disabled={filters.page === 1}
                onClick={() => setFilters({ ...filters, page: filters.page - 1 })}
              >
                Назад
              </button>
              <span>
                Страница {pagination.page || filters.page} из {pagination.pages || 1} (Всего:{' '}
                {pagination.total || filteredPosts.length})
              </span>
              <button
                className="admin-btn admin-btn--small"
                disabled={!pagination.pages || filters.page >= pagination.pages}
                onClick={() => setFilters({ ...filters, page: filters.page + 1 })}
              >
                Вперед
              </button>
            </div>
          )}
        </>
      )}
    </div>
  )
}

export default PostModeration
