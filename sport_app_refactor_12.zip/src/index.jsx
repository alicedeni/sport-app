import React from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from 'react-query'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'

import Welcome from './pages/Welcome'
import PreviewPage from './pages/Preview'
import Feed from './pages/Feed'
import ChallengesPage from './pages/Challenges'
import RatingsPage from './pages/Ratings'
import ActivityPage from './pages/Activity'
import ActivityMakePage from './pages/ActivityMake'
import Profile from './pages/Profile'
import Registration from './pages/Registration'
import ErrorPage404 from './pages/ErrorPage404'
import GlobalGoal from './pages/GlobalGoal'
import Admin from './pages/Admin'
import { ROUTES } from '@constants'

import './scss/main.scss'

const queryClient = new QueryClient()
const router = createBrowserRouter([
  {
    path: '*',
    element: <ErrorPage404 />,
  },
  {
    path: ROUTES.HOME,
    element: <Welcome />,
  },
  {
    path: ROUTES.ABOUT,
    element: <GlobalGoal />,
  },
  {
    path: ROUTES.MAIN,
    element: <Feed />,
  },
  {
    path: ROUTES.CHALLENGES,
    element: <ChallengesPage />,
  },
  {
    path: ROUTES.RATINGS,
    element: <RatingsPage />,
  },
  {
    path: ROUTES.ACTIVITY,
    element: <ActivityPage />,
  },
  {
    path: ROUTES.ACTIVITY_MAKE,
    element: <ActivityMakePage />,
  },
  {
    path: ROUTES.PREVIEW,
    element: <PreviewPage />,
  },
  {
    path: ROUTES.REGISTRATION,
    element: <Registration />,
  },
  {
    path: ROUTES.PROFILE,
    element: <Profile />,
  },
  {
    path: ROUTES.ADMIN,
    element: <Admin />,
  },
])

const container = document.getElementById('root')
const root = createRoot(container)

root.render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </React.StrictMode>,
)
