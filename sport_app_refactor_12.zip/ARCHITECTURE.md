# Архитектура проекта SportApp

## 📁 Структура проекта

```
src/
├── features/                    # Функциональные модули
│   ├── auth/                    # Аутентификация
│   │   ├── components/         # Компоненты аутентификации
│   │   ├── hooks/              # Хуки аутентификации
│   │   ├── services/           # Сервисы аутентификации
│   │   └── index.js            # Экспорты модуля
│   ├── posts/                  # Посты
│   │   ├── components/         # Компоненты постов
│   │   ├── hooks/              # Хуки постов
│   │   ├── services/           # Сервисы постов
│   │   └── index.js            # Экспорты модуля
│   ├── challenges/             # Челленджи
│   │   ├── components/         # Компоненты челленджей
│   │   ├── hooks/              # Хуки челленджей
│   │   ├── services/           # Сервисы челленджей
│   │   └── index.js            # Экспорты модуля
│   ├── activity/               # Активности
│   │   ├── components/         # Компоненты активностей
│   │   ├── hooks/              # Хуки активностей
│   │   ├── services/           # Сервисы активностей
│   │   └── index.js            # Экспорты модуля
│   └── profile/                # Профиль
│       ├── components/         # Компоненты профиля
│       ├── hooks/              # Хуки профиля
│       ├── services/           # Сервисы профиля
│       └── index.js            # Экспорты модуля
├── shared/                     # Общие ресурсы
│   ├── ui/                     # UI компоненты
│   │   ├── Button.jsx         # Кнопка
│   │   ├── Input.jsx          # Поле ввода
│   │   ├── Modal.jsx          # Модальное окно
│   │   ├── LoadingSpinner.jsx # Спиннер загрузки
│   │   ├── ErrorBoundary.jsx  # Обработка ошибок
│   │   └── index.js           # Экспорты UI
│   ├── hooks/                  # Общие хуки
│   │   ├── useUser.js         # Хук пользователя
│   │   ├── useResponsive.js   # Хук адаптивности
│   │   ├── useLocalStorage.js # Хук localStorage
│   │   ├── useDebounce.js     # Хук debounce
│   │   ├── useApi.js          # Хук API
│   │   └── index.js           # Экспорты хуков
│   ├── utils/                  # Утилиты
│   │   ├── declension.js      # Склонение слов
│   │   ├── avatar.js          # Работа с аватарами
│   │   ├── date.js            # Форматирование дат
│   │   ├── validation.js      # Валидация
│   │   ├── performance.js     # Оптимизация
│   │   └── index.js           # Экспорты утилит
│   ├── services/               # Сервисы
│   │   ├── api.js             # Базовый API клиент
│   │   ├── userService.js     # Сервис пользователей
│   │   ├── postService.js     # Сервис постов
│   │   ├── challengeService.js # Сервис челленджей
│   │   ├── activityService.js # Сервис активностей
│   │   ├── authService.js     # Сервис аутентификации
│   │   └── index.js           # Экспорты сервисов
│   └── types/                  # Типы и интерфейсы
│       └── index.ts           # TypeScript типы
├── components/                 # Компоненты (legacy)
│   ├── main/                  # Основные компоненты
│   ├── mobile/                # Мобильные компоненты
│   ├── profile/               # Компоненты профиля
│   └── ui/                    # UI компоненты (legacy)
├── pages/                     # Страницы
│   ├── Feed.jsx              # Лента
│   ├── Challenges.jsx        # Челленджи
│   ├── Activity.jsx          # Активности
│   ├── Profile.jsx           # Профиль
│   └── ...
├── constants/                 # Константы
│   ├── api.js                # API константы
│   ├── routes.js             # Маршруты
│   └── ui.js                 # UI константы
├── context/                   # React контексты
│   └── AppContext.js         # Основной контекст
├── scss/                      # Стили
│   ├── base/                 # Базовые стили
│   ├── blocks/               # Блоки стилей
│   └── main.scss             # Главный файл стилей
├── assets/                    # Ресурсы
│   ├── images/               # Изображения
│   ├── icons/                # Иконки
│   └── fonts/                # Шрифты
└── index.jsx                  # Точка входа
```

## 🏗️ Принципы архитектуры

### 1. Feature-Based Architecture

Каждая функциональность выделена в отдельный модуль (`features/`), который содержит:

- **components/** - компоненты, специфичные для этой функциональности
- **hooks/** - хуки, специфичные для этой функциональности
- **services/** - API сервисы для этой функциональности
- **index.js** - экспорты модуля

### 2. Shared Resources

Общие ресурсы вынесены в `shared/`:

- **ui/** - переиспользуемые UI компоненты
- **hooks/** - общие хуки
- **utils/** - утилиты
- **services/** - общие сервисы
- **types/** - типы и интерфейсы

### 3. Separation of Concerns

- **Компоненты** отвечают только за отображение
- **Хуки** управляют состоянием и логикой
- **Сервисы** обрабатывают API запросы
- **Утилиты** содержат чистые функции

## 🔧 Алиасы Vite

```javascript
// vite.config.js
resolve: {
  alias: {
    '@': resolve(__dirname, 'src'),
    '@features': resolve(__dirname, 'src/features'),
    '@shared': resolve(__dirname, 'src/shared'),
    '@components': resolve(__dirname, 'src/components'),
    '@pages': resolve(__dirname, 'src/pages'),
    '@constants': resolve(__dirname, 'src/constants'),
    '@context': resolve(__dirname, 'src/context'),
    '@assets': resolve(__dirname, 'src/assets'),
    '@scss': resolve(__dirname, 'src/scss')
  }
}
```

## 📦 Импорты

### Из features модулей:

```javascript
import { Post, Posts } from '@features/posts'
import { Challenge } from '@features/challenges'
import { Activity } from '@features/activity'
```

### Из shared ресурсов:

```javascript
import { Button, Modal } from '@shared/ui'
import { useUser, useResponsive } from '@shared/hooks'
import { formatDate, validateEmail } from '@shared/utils'
import { userService, postService } from '@shared/services'
```

### Из констант:

```javascript
import { ROUTES, API_ENDPOINTS } from '@constants'
```

## 🎯 Преимущества новой архитектуры

1. **Модульность** - каждая функциональность изолирована
2. **Переиспользование** - общие компоненты и утилиты в shared
3. **Масштабируемость** - легко добавлять новые features
4. **Читаемость** - четкая структура и разделение ответственности
5. **Тестируемость** - изолированные модули легче тестировать
6. **Производительность** - возможность lazy loading модулей

## 🚀 Миграция

Проект постепенно мигрирует с legacy структуры на новую архитектуру:

- ✅ Создана новая структура папок
- ✅ Перенесены хуки и утилиты в shared
- ✅ Созданы базовые UI компоненты
- ✅ Обновлены импорты
- 🔄 Миграция компонентов в features (в процессе)
- ⏳ Обновление стилей по модулям
- ⏳ Добавление TypeScript типов

